class Guesser:

    def __init__(self,number=0):

        self.numberinMind = number
